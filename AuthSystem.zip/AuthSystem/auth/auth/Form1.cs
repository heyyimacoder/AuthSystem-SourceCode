﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace auth
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        private void checkbttn_Click(object sender, EventArgs e)
        {
            if  (this.keyText.Text == "ABGIHJA")  { //check key
                MessageBox.Show("Valid Key! Have Fun :D", "Open Source"); //messagebox
                Main main = new Main();
                main.Show(); //show the next form
                this.Hide(); //hide this form
            }
           else
            {
                MessageBox.Show("Invalid Key :(", "Open Source"); //invalid key
            }
            
        }

        private void Form1_Load(object sender, EventArgs e)
        {
            
        }
    }
}
